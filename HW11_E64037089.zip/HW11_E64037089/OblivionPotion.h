//
//  OblivionPotion.h
//  
//
//  Created by ZOUMA Adama on 6/4/18.
//

#ifndef OblivionPotion_h
#define OblivionPotion_h

#include "ConsumableItem.h"

class OblivionPotion: public ConsumableItem
{
    
};
#endif /* OblivionPotion_h */
