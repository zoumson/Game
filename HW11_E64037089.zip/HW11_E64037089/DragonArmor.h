//
//  DragonArmor.h
//  
//
//  Created by ZOUMA Adama on 6/3/18.
//

#ifndef DragonArmor_h
#define DragonArmor_h
#include "ArmorItem.h"
class DragonArmor: public ArmorItem
{
    
};
#endif /* DragonArmor_h */
