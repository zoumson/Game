//
//  ShieldArmor.h
//  
//
//  Created by ZOUMA Adama on 6/4/18.
//

#ifndef ShieldArmor_h
#define ShieldArmor_h
#include "ArmorItem.h"
class ShieldArmor: public ArmorItem
{
    
};
#endif /* ShieldArmor_h */
