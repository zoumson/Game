//
//  DaggerWeapon.h
//  
//
//  Created by ZOUMA Adama on 6/3/18.
//

#ifndef DaggerWeapon_h
#define DaggerWeapon_h
#include "WeaponItem.h"
class DaggerWeapon: public WeaponItem
{
    
};


#endif /* DaggerWeapon_h */
