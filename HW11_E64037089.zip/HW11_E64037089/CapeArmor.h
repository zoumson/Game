//
//  CapeArmor.h
//  
//
//  Created by ZOUMA Adama on 6/4/18.
//

#ifndef CapeArmor_h
#define CapeArmor_h
#include "ArmorItem.h"
class CapeArmor: public ArmorItem
{
    
};


#endif /* CapeArmor_h */
