//
//  DoubletArmor.h
//  
//
//  Created by ZOUMA Adama on 6/3/18.
//

#ifndef DoubletArmor_h
#define DoubletArmor_h
#include "ArmorItem.h"
class DoubletArmor: public ArmorItem
{
    
};


#endif /* DoubletArmor_h */
