//
//  HalberdWeapon.h
//  
//
//  Created by ZOUMA Adama on 6/3/18.
//

#ifndef HalberdWeapon_h
#define HalberdWeapon_h
#include "WeaponItem.h"

class HalberdWeapon: public WeaponItem
{
    
};

#endif /* HalberdWeapon_h */
