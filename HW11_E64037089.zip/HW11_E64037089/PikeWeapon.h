//
//  PikeWeapon.h
//  
//
//  Created by ZOUMA Adama on 6/3/18.
//

#ifndef PikeWeapon_h
#define PikeWeapon_h
#include "WeaponItem.h"
class PikeWeapon: public WeaponItem
{
    
};

#endif /* PikeWeapon_h */
