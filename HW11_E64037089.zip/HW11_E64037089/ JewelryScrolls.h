//
//   JewelryScrolls.h
//  
//
//  Created by ZOUMA Adama on 6/4/18.
//

#ifndef _JewelryScrolls_h
#define _JewelryScrolls_h
#include "ConsumableItem.h"

class JewelryScrolls: public ConsumableItem
{
    
};
#endif /* _JewelryScrolls_h */
