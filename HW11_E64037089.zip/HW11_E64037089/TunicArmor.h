//
//  TunicArmor.h
//  
//
//  Created by ZOUMA Adama on 6/3/18.
//

#ifndef TunicArmor_h
#define TunicArmor_h
#include "ArmorItem.h"
class TunicArmor: public ArmorItem
{
    
};

#endif /* TunicArmor_h */
