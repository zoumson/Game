//
//  PreservationPotion.h
//  
//
//  Created by ZOUMA Adama on 6/4/18.
//

#ifndef PreservationPotion_h
#define PreservationPotion_h

#include "ConsumableItem.h"

class PreservationPotion: public ConsumableItem
{
    
};
#endif /* PreservationPotion_h */
