//
//  ScepterWeapon.h
//  
//
//  Created by ZOUMA Adama on 6/3/18.
//

#ifndef ScepterWeapon_h
#define ScepterWeapon_h
#include "WeaponItem.h"
class ScepterWeapon: public WeaponItem
{
    
};


#endif /* ScepterWeapon_h */
