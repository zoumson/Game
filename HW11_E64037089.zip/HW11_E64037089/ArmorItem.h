//
//  ArmorItem.h
//  try
//
//  Created by ZOUMA Adama on 5/28/18.
//  Copyright © 2018 ZOUMA Adama. All rights reserved.
//

#ifndef ArmorItem_h
#define ArmorItem_h
#include "Item.h"
class ArmorItem: public Item
{
public:
    //const public data member
    int defense_increment; //the number of increment on defense after equipping this item
    

};



#endif /* ArmorItem_h */
