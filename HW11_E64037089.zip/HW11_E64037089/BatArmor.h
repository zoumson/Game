//
//  BatArmor.h
//  
//
//  Created by ZOUMA Adama on 6/4/18.
//

#ifndef BatArmor_h
#define BatArmor_h
#include "ArmorItem.h"
class BatArmor: public ArmorItem
{
    
};
#endif /* BatArmor_h */
