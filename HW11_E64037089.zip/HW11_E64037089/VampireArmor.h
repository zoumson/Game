//
//  VampireArmor.h
//  
//
//  Created by ZOUMA Adama on 6/4/18.
//

#ifndef VampireArmor_h
#define VampireArmor_h
#include "ArmorItem.h"
class VampireArmor: public ArmorItem
{
    
};


#endif /* VampireArmor_h */
