//
//  TeleportScrolls.h
//  
//
//  Created by ZOUMA Adama on 6/4/18.
//

#ifndef TeleportScrolls_h
#define TeleportScrolls_h
#include "ConsumableItem.h"

class TeleportScrolls: public ConsumableItem
{
    
};
#endif /* TeleportScrolls_h */
