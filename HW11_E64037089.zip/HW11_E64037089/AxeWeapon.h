//
//  AxeWeapon.h
//  
//
//  Created by ZOUMA Adama on 6/3/18.
//

#ifndef AxeWeapon_h
#define AxeWeapon_h
#include "WeaponItem.h"

class AxeWeapon: public WeaponItem
{
    
};

#endif /* AxeWeapon_h */
