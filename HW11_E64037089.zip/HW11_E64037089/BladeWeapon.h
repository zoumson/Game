//
//  BladeWeapon.h
//  
//
//  Created by ZOUMA Adama on 6/3/18.
//

#ifndef BladeWeapon_h
#define BladeWeapon_h
#include "WeaponItem.h"

class BladeWeapon: public WeaponItem
{
    
};

#endif /* BladeWeapon_h */
