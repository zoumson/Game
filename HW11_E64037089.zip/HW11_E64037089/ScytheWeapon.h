//
//  ScytheWeapon.h
//  
//
//  Created by ZOUMA Adama on 6/3/18.
//

#ifndef ScytheWeapon_h
#define ScytheWeapon_h
#include "WeaponItem.h"
class ScytheWeapon: public WeaponItem
{
    
};

#endif /* ScytheWeapon_h */
