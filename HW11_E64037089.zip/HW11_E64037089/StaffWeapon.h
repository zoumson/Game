//
//  StaffWeapon.h
//  
//
//  Created by ZOUMA Adama on 6/3/18.
//

#ifndef StaffWeapon_h
#define StaffWeapon_h
#include "WeaponItem.h"
class StaffWeapon: public WeaponItem
{
    
};

#endif /* StaffWeapon_h */
