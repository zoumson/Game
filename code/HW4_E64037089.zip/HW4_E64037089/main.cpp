//
#include <stdio.h>
#include "Maze.h"
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <iomanip>


using namespace std;


int main() {
    
  
    Maze maze;
    maze.readPrintMaze();
   
    return  0;
    
    
}
    
   
        

































 
