//
//  SwordWeapon.h
//  
//
//  Created by ZOUMA Adama on 6/3/18.
//

#ifndef SwordWeapon_h
#define SwordWeapon_h
#include "WeaponItem.h"

class SwordWeapon: public WeaponItem
{
    
};


#endif /* SwordWeapon_h */
