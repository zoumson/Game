//
//  LifePotion.h
//  
//
//  Created by ZOUMA Adama on 6/3/18.
//

#ifndef LifePotion_h
#define LifePotion_h
#include "ConsumableItem.h"

class LifePotion: public ConsumableItem
{
    
};


#endif /* LifePotion_h */
