//
//  Battle.h
//  try
//
//  Created by ZOUMA Adama on 5/15/18.
//  Copyright © 2018 ZOUMA Adama. All rights reserved.
//

#ifndef Battle_h
#define Battle_h
#include "GeneralPlayer.h"
#include "AbstractMonster.h"
#include "OrcPlayer.h"
#include"MagicianPlayer.h"
#include "KnightPlayer.h"
#include "GoblinMonster.h"
#include "JWMonster.h"
#include "ZombieMonster.h"
#include <iostream>
#include <string>
#include <stdlib.h>
#include <vector>
#include <ctime>    // For time()
#include <cstdlib>  // For srand() and rand()



using namespace std;




class Battle
{
    
    
    
public:
    
      Battle(int nPlyr, int nMon);

   
    
    
    
    
    private:
    
    
   


    
    
    
    
};




#endif /* Battle_h */
