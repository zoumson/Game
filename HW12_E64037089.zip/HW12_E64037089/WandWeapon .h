//
//  WandWeapon .h
//  
//
//  Created by ZOUMA Adama on 6/3/18.
//

#ifndef WandWeapon__h
#define WandWeapon__h
#include "WeaponItem.h"

class WandWeapon: public WeaponItem
{
    
};

#endif /* WandWeapon__h */
