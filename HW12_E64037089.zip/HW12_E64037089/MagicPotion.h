//
//  MagicPotion.h
//  
//
//  Created by ZOUMA Adama on 6/3/18.
//

#ifndef MagicPotion_h
#define MagicPotion_h
#include "ConsumableItem.h"

class MagicPotion: public ConsumableItem
{
    
};

#endif /* MagicPotion_h */
