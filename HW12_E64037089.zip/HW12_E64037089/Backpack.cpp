//
//  Backpack.cpp
//  myRpg
//
//  Created by ZOUMA Adama on 6/27/18.
//  Copyright © 2018 ZOUMA Adama. All rights reserved.
//

#include <stdio.h>
#include<iostream>
#include"Backpack.h"
#include<vector>
#include"ConsumableItem.h"

using namespace std;

Backpack::Backpack( int n_s)
{
    vector<Backpack *> b(n_s);
    ConsumableItem c();
    /*b[0] = &c;*/
}
